// Mobile nav toggle
const navToggle = document.getElementById("navToggle");
const rail = document.getElementById("rail");

navToggle.addEventListener("click", () => {
  rail.classList.toggle("open");
});

// Close mobile nav after clicking a link
document.querySelectorAll(".rail-link").forEach(link => {
  link.addEventListener("click", () => {
    rail.classList.remove("open");
  });
});

// Scroll-reveal animation for sections
const sections = document.querySelectorAll(".section");

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting){
      entry.target.classList.add("in-view");
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });

sections.forEach(section => revealObserver.observe(section));

// Scrollspy: highlight the active nav link based on scroll position
const navLinks = document.querySelectorAll(".rail-link");

const spyObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    const id = entry.target.getAttribute("id");
    const link = document.querySelector(`.rail-link[href="#${id}"]`);
    if (!link) return;
    if (entry.isIntersecting){
      navLinks.forEach(l => l.classList.remove("active"));
      link.classList.add("active");
    }
  });
}, { rootMargin: "-40% 0px -50% 0px", threshold: 0 });

sections.forEach(section => spyObserver.observe(section));
